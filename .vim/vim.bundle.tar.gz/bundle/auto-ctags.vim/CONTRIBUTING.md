1. Fork it
2. Create your feature branch (`git checkout -b my-new-feature`)
3. Add change
4. Run the tests (`bundle && rake spec`)
5. Commit your changes (`git commit -am 'Add some feature'`)
6. Push to the branch (`git push origin my-new-feature`)
7. Create new Pull Request
